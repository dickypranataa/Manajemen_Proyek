

<?php $__env->startSection('content'); ?>

<div class="container mx-auto px-6 py-8">
    <h1 class="text-3xl font-semibold mb-4">Daftar Barang</h1>

    <!-- Pencarian Barang -->
    <div class="mb-4">
        <form action="<?php echo e(route('barang.index')); ?>" method="GET" class="flex">
            <input type="text" name="search" placeholder="Cari Nama Barang..." class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300 focus:outline-none" value="<?php echo e(request('search')); ?>">
            <button type="submit" class="ml-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition">Cari</button>
        </form>
    </div>

    <?php if(session('success')): ?>
    <div class="mb-4 text-green-500">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="mb-4">
        <a href="<?php echo e(route('barang.create')); ?>" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">Tambah Barang</a>
        <a href="<?php echo e(route('barang.show')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">Tambah Stok</a>
    </div>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-blue-500 text-white">
                    <th class="px-4 py-2 text-left text-sm font-medium">ID</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Nama Barang</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Satuan</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Stok</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Terakhir Diperbarui</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Tanggal Kadaluarsa</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Minimum Stok</th>
                    <th class="px-4 py-2 text-left text-sm font-medium">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t hover:bg-gray-50 <?php if($item->stok <= $item->minimum_Stok): ?> bg-red-200 
                <?php elseif(($item->tgl_kadaluarsa)->lessThan(now())): ?> bg-red-200 
                <?php endif; ?>">
                <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->id_barang); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->nama_Barang); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->satuan); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->stok); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->tanggal->format('Y-m-d')); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->tgl_kadaluarsa->format('Y-m-d')); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->minimum_Stok); ?></td>
                    <td class="px-4 py-2 text-sm">
                        <a href="<?php echo e(route('barang.edit', $item->id_barang)); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition">Edit</a>

                        <a href="<?php echo e(route('barang.ambil', $item->id_barang)); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">Ambil</a>

                        <form action="<?php echo e(route('barang.destroy', $item->id_barang)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\MPTI\manajemen_stok_barang\resources\views/barang/index.blade.php ENDPATH**/ ?>