

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-10 px-4">
    <!-- Header Dashboard -->
    <h1 class="text-3xl font-bold text-center mb-8 text-gray-800">Dashboard</h1>

    <!-- Statistik Total -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <!-- Total Barang Masuk -->
        <div class="bg-green-500 text-white rounded-lg shadow-md p-6 text-center">
            <h2 class="text-xl font-semibold">Total Barang Masuk</h2>
            <p class="text-4xl mt-2 font-bold"><?php echo e($totalBarangMasuk); ?></p>
            <a href="<?php echo e(route('barang.index')); ?>" class="text-sm text-white hover:underline mt-2 inline-block">Lihat Barang</a> <!-- Link ke barang -->
        </div>

        <!-- Total Barang Keluar -->
        <div class="bg-red-500 text-white rounded-lg shadow-md p-6 text-center">
            <h2 class="text-xl font-semibold">Total Barang Keluar</h2>
            <p class="text-4xl mt-2 font-bold"><?php echo e($totalBarangKeluar); ?></p>
            <a href="<?php echo e(route('transaksi.index')); ?>" class="text-sm text-white hover:underline mt-2 inline-block">Lihat Transaksi</a> <!-- Link ke transaksi -->
        </div>

        <!-- Total Stok Gudang -->
        <div class="bg-blue-500 text-white rounded-lg shadow-md p-6 text-center">
            <h2 class="text-xl font-semibold">Total Stok Gudang</h2>
            <p class="text-4xl mt-2 font-bold"><?php echo e($totalStok); ?></p>
            <a href="<?php echo e(route('barang.index')); ?>" class="text-sm text-white hover:underline mt-2 inline-block">Lihat Stok</a> <!-- Link ke barang -->
        </div>

        <!-- Total User -->
        <div class="bg-purple-500 text-white rounded-lg shadow-md p-6 text-center">
            <h2 class="text-xl font-semibold">Total User</h2>
            <p class="text-4xl mt-2 font-bold"><?php echo e($totalUser); ?></p>
            <a href="<?php echo e(route('users.index')); ?>" class="text-sm text-white hover:underline mt-2 inline-block">Lihat User</a> <!-- Link ke user -->
        </div>
    </div>

    <!-- Link ke Laporan -->
    <div class="mt-10 text-center">
        <a href="<?php echo e(route('laporan.index')); ?>" class="text-xl text-blue-500 hover:underline">Lihat Laporan</a> <!-- Link ke laporan -->
    </div>

    <!-- Link ke Notifikasi -->
    <div class="mt-10 text-center">
        <a href="<?php echo e(route('notifikasi.index')); ?>" class="text-xl text-yellow-500 hover:underline">Notifikasi Barang Kadaluarsa</a> <!-- Link ke notifikasi -->
    </div>
</div>

    <!-- Diagram Transaksi Bulanan -->
    <div class="mt-10 bg-white shadow-md rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">Diagram Transaksi Masuk & Keluar per Bulan</h2>
        <canvas id="monthlyTransactionChart"></canvas>
    </div>

    
    <!-- Tabel Transaksi Terbaru -->
    <?php if($user->role == 'admin' || 'employee'): ?>
    <div class="mt-10 bg-white shadow-md rounded-lg overflow-hidden">
        <div class="px-6 py-4 bg-gray-800 text-white">
            <h2 class="text-xl font-bold">5 Transaksi Terbaru</h2>
        </div>
        <div class="p-4 overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Jumlah Barang</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipe</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($index + 1); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaksi->jml_barang); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e(ucfirst($transaksi->tipe)); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($transaksi->created_at->format('d M Y H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Script untuk Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Mendeklarasikan variabel JavaScript untuk menyimpan data PHP
    var monthlyData = <?php echo json_encode($allMonthsData, 15, 512) ?>;
    
    // Menyiapkan data bulan dan nilai transaksi masuk dan keluar
    var months = [];
    var totalIn = [];
    var totalOut = [];
    
    monthlyData.forEach(function(data) {
        months.push(data.month_name);
        totalIn.push(data.total_in);
        totalOut.push(data.total_out);
    });

    // Membuat Chart.js dengan data yang telah dipersiapkan
    const ctx = document.getElementById('monthlyTransactionChart').getContext('2d');
    const monthlyTransactionChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months,  // Nama Bulan
            datasets: [{
                label: 'Barang Masuk',
                data: totalIn,
                backgroundColor: '#22c55e',
                borderColor: '#16a34a',
                borderWidth: 1
            }, {
                label: 'Barang Keluar',
                data: totalOut,
                backgroundColor: '#ef4444',
                borderColor: '#dc2626',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 10
                    }
                }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\hapus\manajemen_stok_barang\manajemen_stok_barang\resources\views/dashboard.blade.php ENDPATH**/ ?>