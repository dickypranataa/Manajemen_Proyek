

<?php $__env->startSection('content'); ?>

<div class="container mx-auto px-6 py-8">
    <h1 class="text-3xl font-semibold text-center mb-10">Daftar Transaksi</h1>

    <?php if(session('success')): ?>
    <div class="mb-4 text-green-500">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <!-- Form Filter Tanggal dan Tipe -->
    <form action="<?php echo e(route('transaksi.generate')); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="flex space-x-4">
            <div>
                <label for="start_date" class="text-sm font-medium text-gray-600">Tanggal Mulai:</label>
                <input type="date" name="start_date" id="start_date" class="px-4 py-2 border border-gray-300 rounded-lg" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div>
                <label for="end_date" class="text-sm font-medium text-gray-600">Tanggal Selesai:</label>
                <input type="date" name="end_date" id="end_date" class="px-4 py-2 border border-gray-300 rounded-lg" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div>
                <label for="tipe" class="text-sm font-medium text-gray-600">Tipe:</label>
                <select name="tipe" id="tipe" class="px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Semua</option>
                    <option value="in" <?php echo e(request('tipe') == 'in' ? 'selected' : ''); ?>>In</option>
                    <option value="out" <?php echo e(request('tipe') == 'out' ? 'selected' : ''); ?>>Out</option>
                </select>
            </div>
            <button type="submit" class="px-6 py-2 bg-blue-500 text-white rounded-lg">Filter</button>
        </div>
    </form>

    <?php if(isset($transaksi)): ?>
    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">ID</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Barang</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Tanggal</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Jumlah</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Diubah</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Tipe</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($trx->id_transaksi); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($trx->barang->nama_Barang); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($trx->tgl_transaksi); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($trx->jml_barang); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($trx->user->name); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(ucfirst($trx->tipe)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-4 py-2 text-sm text-gray-700 text-center">Tidak ada transaksi untuk tanggal yang dipilih atau filter lainnya.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\MPTI\manajemen_stok_barang\resources\views/transaksi/index.blade.php ENDPATH**/ ?>