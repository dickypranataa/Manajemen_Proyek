

<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('storage/images.jpeg')); ?>" class="w-full" alt="Gambar">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\github dicky\manajemen_stok_barang\manajemen_stok_barang\resources\views/dashboard.blade.php ENDPATH**/ ?>