<?php $user = Auth::user() ?>

<!-- Sidebar -->
<div id="sidebar" class="bg-gray-800 text-white w-64 min-h-screen fixed md:relative transition-transform duration-300 ease-in-out -translate-x-full md:translate-x-0 z-40">
    <div class="p-6">
        <h4 class="text-2xl font-bold">Admin Dashboard</h4>
    </div>
    <div class="space-y-2">
        <!-- Menu Dashboard -->
        <a href="<?php echo e(route('dashboard.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Dashboard</a>

        <!-- Menu Notifikasi -->
        <a href="<?php echo e(route('notifikasi.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition flex items-center">
            Notifikasi
            <?php if(isset($totalNotifications)): ?>
            <?php if($totalNotifications > 0): ?>
            <span class="ml-2 bg-red-600 text-white text-sm font-bold px-2 py-1 rounded-full">
                <?php echo e($totalNotifications); ?>

            </span>
            <?php endif; ?>
            <?php endif; ?>
        </a>

        <!-- Menu Users -->
        <?php if($user->role == 'admin'): ?>
        <a href="<?php echo e(route('users.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Users List</a>
        <?php endif; ?>

        <!-- Menu Barang -->
        <?php if($user->role == 'admin' || $user->role == 'employee'): ?>
        <a href="<?php echo e(route('barang.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Barang</a>
        <?php endif; ?>

        <?php if($user->role == 'admin'): ?>
        <a href="<?php echo e(route('transaksi.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Transaksi</a>
        <?php endif; ?>

        <?php if($user->role == 'admin'): ?>
        <a href="<?php echo e(route('laporan.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Laporan</a>
        <?php endif; ?>

        <!-- Menu Logout -->
        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline w-full">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block py-2 px-4 hover:bg-gray-700 rounded transition text-left w-full">
                Logout
            </button>
        </form>
    </div>
</div>

<!-- Tombol Toggle -->
<button id="sidebar-toggle" class="md:hidden fixed top-4 left-4 z-50 bg-gray-800 text-white p-2 rounded">
    ☰
</button>

<!-- JavaScript untuk Toggle -->
<script>
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('sidebar');

    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('-translate-x-full'); // Toggle sidebar
    });
</script><?php /**PATH D:\Semester 5\MPTI\manajemen_stok_barang\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>