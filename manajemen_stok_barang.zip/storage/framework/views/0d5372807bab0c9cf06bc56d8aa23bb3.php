<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kirim Email</title>
    <!-- Tambahkan link CSS jika diperlukan -->
</head>
<body>
    <h1>Kirim Email</h1>

    <!-- Form untuk mengirim email -->
    <form action="<?php echo e(route('send.email')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Input untuk email penerima -->
        <div>
            <label for="email">Email Penerima:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <!-- Input untuk subjek email -->
        <div>
            <label for="subject">Subjek:</label>
            <input type="text" id="subject" name="subject" required>
        </div>

        <!-- Input untuk isi pesan email -->
        <div>
            <label for="message">Pesan:</label>
            <textarea id="message" name="message" rows="5" required></textarea>
        </div>

        <!-- Tombol Kirim -->
        <button type="submit">Kirim Email</button>
    </form>
</body>
</html>
<?php /**PATH D:\kuliah\github dicky\manajemen_stok_barang\manajemen_stok_barang\resources\views/emails/orderShipped.blade.php ENDPATH**/ ?>