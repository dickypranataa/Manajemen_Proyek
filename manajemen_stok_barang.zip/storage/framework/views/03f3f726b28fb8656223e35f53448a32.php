
<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6 text-center">Daftar Users</h1>
    <a href="<?php echo e(route('users.create')); ?>" class="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300 mb-4 inline-block">
        Tambah User
    </a>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full table-auto text-sm">
            <thead class="bg-blue-500 text-white">
                <tr>
                    <th class="py-3 px-2 sm:px-6 text-left font-medium">ID</th>
                    <th class="py-3 px-2 sm:px-6 text-left font-medium">Username</th>
                    <th class="py-3 px-2 sm:px-6 text-left font-medium">Role</th>
                    <th class="py-3 px-2 sm:px-6 text-left font-medium">Tanggal Dibuat</th>
                    <th class="py-3 px-2 sm:px-6 text-center font-medium">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="py-3 px-2 sm:px-6"><?php echo e($user->id); ?></td>
                    <td class="py-3 px-2 sm:px-6"><?php echo e($user->name); ?></td>
                    <td class="py-3 px-2 sm:px-6"><?php echo e($user->role); ?></td>
                    <td class="py-3 px-2 sm:px-6"><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                    <td class="py-3 px-2 sm:px-6 text-center flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-3">
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="bg-yellow-400 text-white py-1 px-3 rounded-lg hover:bg-yellow-600 transition">
                            Edit
                        </a>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" class="inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-400 text-white py-1 px-3 rounded-lg hover:bg-red-700 transition">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\MPTI\manajemen_stok_barang\resources\views/users/index.blade.php ENDPATH**/ ?>