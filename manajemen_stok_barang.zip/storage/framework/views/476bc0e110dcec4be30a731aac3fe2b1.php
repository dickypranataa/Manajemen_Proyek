<?php $user = Auth::user() ?>

<!-- resources/views/layouts/sidebar.blade.php -->
<div class="bg-gray-800 text-white w-64 min-h-screen">
    <div class="p-6">
        <h4 class="text-2xl font-bold">Admin Dashboard</h4>
    </div>
    <div class="space-y-2">
        <!-- Menu Dashboard -->
        <a href="<?php echo e(route('dashboard.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Dashboard</a>

        <!-- Menu Notifikasi -->
        <a href="<?php echo e(route('notifikasi.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition flex items-center">
            Notifikasi
            <?php if(isset($totalNotifications)): ?>
            <?php if($totalNotifications > 0): ?>
            <span class="ml-2 bg-red-600 text-white text-sm font-bold px-2 py-1 rounded-full">
                <?php echo e($totalNotifications); ?>

            </span>
            <?php endif; ?>
            <?php endif; ?>
        </a>

        <!-- Menu Users -->
        <?php if($user->role == 'admin'): ?>
            <a href="<?php echo e(route('users.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Users List</a>
        <?php endif; ?>


        <!-- Menu Barang -->
        <?php if($user->role == 'admin' || $user->role == 'employee'): ?>
        <a href="<?php echo e(route('barang.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Barang</a>
        <?php endif; ?>

        <?php if($user->role == 'admin'): ?>
        <a href="<?php echo e(route('transaksi.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Transaksi</a>
        <?php endif; ?>

        <?php if($user->role == 'admin'): ?>
        <a href="<?php echo e(route('laporan.index')); ?>" class="block py-2 px-4 hover:bg-gray-700 rounded transition">Laporan</a>
        <?php endif; ?>


        <!-- Menu Logout -->
        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline" style="width:max-content">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block py-2 px-4 hover:bg-gray-700 rounded transition" style="width:100%; text-align:left">
                Logout
            </button>
        </form>
    </div>
</div><?php /**PATH D:\kuliah\hapus\manajemen_stok_barang\manajemen_stok_barang\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>