<form method="get" action="mailto:<?php echo e($emailAddress); ?>?subject=<?php echo e($subject); ?>">
    <textarea name="message" placeholder="Tulis pesan"></textarea>
    <button type="submit">Kirim Email</button>
</form>
<?php /**PATH D:\kuliah\hapus\manajemen_stok_barang\manajemen_stok_barang\resources\views/email/email.blade.php ENDPATH**/ ?>