

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-6 py-8" id="printableContainer">
    <h1 class="text-3xl font-semibold mb-4 flex items-center">
        Notifikasi
    </h1>


    <!-- Barang Hampir Habis -->
    <h2 class="text-2xl font-semibold">Barang Hampir Habis</h2>
    <?php if($barangAlmostOutOfStock->isEmpty()): ?>
    <p class="text-gray-600">Tidak ada barang yang hampir habis.</p>
    <?php else: ?>
    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Nama Barang</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Stok</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Minimum Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $barangAlmostOutOfStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->nama_Barang); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->stok); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->minimum_Stok); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- Barang Hampir Kadaluarsa -->
    <h2 class="text-2xl font-semibold mt-10">Barang Hampir Kadaluarsa</h2>
    <?php if($barangExpiringSoon->isEmpty()): ?>
    <p class="text-gray-600">Tidak ada barang yang hampir kadaluarsa dalam 7 hari ke depan.</p>
    <?php else: ?>
    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Nama Barang</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Tanggal Kadaluarsa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $barangExpiringSoon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->nama_Barang); ?></td>
                    <!-- Format tanggal kadaluarsa -->
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($item->tgl_kadaluarsa)->format('d-m-Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- Barang Sudah Kadaluarsa -->
    <h2 class="text-2xl font-semibold mt-10">Barang Sudah Kadaluarsa</h2>
    <?php if($barangExpired->isEmpty()): ?>
    <p class="text-gray-600">Tidak ada barang yang sudah kadaluarsa.</p>
    <?php else: ?>
    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Nama Barang</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-600">Tanggal Kadaluarsa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $barangExpired; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($item->nama_Barang); ?></td>
                    <!-- Format tanggal kadaluarsa -->
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($item->tgl_kadaluarsa)->format('d-m-Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\github dicky\manajemen_stok_barang\manajemen_stok_barang\resources\views/barang/notifikasi.blade.php ENDPATH**/ ?>